"use client";
import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { name: "Home", href: "/", active: true },
    { name: "Services", href: "/services", active: false },
    { name: "About", href: "/about", active: false },
    { name: "Contact", href: "/contact", active: false },
  ];

  return (
    <header
      className={`sticky top-0 z-50 bg-white dark:bg-[#1E1E1E] border-b border-[#E9E9E9] dark:border-[#333333] transition-shadow duration-150 ease-out ${
        isScrolled
          ? "shadow-[0_2px_6px_rgba(0,0,0,0.06)] dark:shadow-[0_2px_6px_rgba(0,0,0,0.3)]"
          : ""
      }`}
      style={{
        fontFamily:
          'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      }}
    >
      <div className="px-6 sm:px-4 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          {/* Brand area - Left */}
          <div className="flex items-center gap-3">
            <a href="/">
              <img
                src="https://ucarecdn.com/8c69145d-b262-401f-b925-a64a01a71206/-/format/auto/"
                alt="FIRESEC SYSTEMS Logo"
                className="h-16 md:h-20 w-auto hover:opacity-90 transition-opacity duration-150"
              />
            </a>
          </div>

          {/* Desktop Navigation - Center */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className={`text-sm font-medium transition-colors duration-150 ease-out ${
                  item.active
                    ? "bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 px-4 py-2 rounded-full"
                    : "text-gray-600 dark:text-gray-300 hover:text-red-600 dark:hover:text-red-400"
                }`}
              >
                {item.name}
              </a>
            ))}
          </nav>

          {/* Right side - CTA and Mobile Menu */}
          <div className="flex items-center gap-4">
            {/* Mobile menu button */}
            <button
              className="md:hidden p-2 text-gray-600 dark:text-gray-300 hover:text-red-600 dark:hover:text-red-400 transition-colors duration-150"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>

            {/* CTA Button */}
            <a
              href="/contact"
              className="bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-semibold text-sm px-6 py-3 rounded-lg transition-all duration-150 ease-out active:scale-[0.98] shadow-lg inline-flex items-center"
              style={{ height: "44px" }}
            >
              Get Quote
            </a>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {isMenuOpen && (
        <div className="md:hidden bg-white dark:bg-[#1E1E1E] border-t border-[#E9E9E9] dark:border-[#333333] py-4">
          <nav className="flex flex-col gap-4 px-6">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className={`text-sm font-medium transition-colors duration-150 ease-out ${
                  item.active
                    ? "bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 px-4 py-2 rounded-lg self-start"
                    : "text-gray-600 dark:text-gray-300 hover:text-red-600 dark:hover:text-red-400"
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                {item.name}
              </a>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
