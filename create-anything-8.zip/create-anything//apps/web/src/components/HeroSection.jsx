import { Shield, Phone, Clock } from "lucide-react";

export default function HeroSection() {
  return (
    <section
      className="pt-12 pb-24 px-6 bg-white"
      style={{
        fontFamily:
          'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      }}
    >
      <div className="max-w-7xl mx-auto">
        {/* Hero Content */}
        <div className="p-8 md:p-16 lg:p-20">
          {/* Large FIRESEC Logo */}
          <div className="flex justify-center mb-12">
            <a href="/">
              <img
                src="https://ucarecdn.com/8c69145d-b262-401f-b925-a64a01a71206/-/format/auto/"
                alt="FIRESEC SYSTEMS Logo"
                className="h-48 md:h-64 lg:h-80 w-auto hover:opacity-90 transition-opacity duration-150"
                style={{ filter: "drop-shadow(0 4px 8px rgba(0,0,0,0.1))" }}
              />
            </a>
          </div>

          {/* Row A - Intro eyebrow */}
          <div className="flex items-baseline justify-center gap-2 mb-8">
            <Shield className="w-5 h-5 text-red-600" />
            <p className="text-gray-600 text-[14px] md:text-[15px] font-normal text-center">
              Professional fire & security solutions across Scotland
            </p>
          </div>

          {/* Row B - Headline stack */}
          <h1
            className="text-gray-900 font-normal leading-[1.05] mb-10 text-center"
            style={{
              fontSize: "clamp(32px, 6vw, 72px)",
            }}
          >
            Protecting your property
            <br />
            with <span className="text-red-600">21+ years</span>
            <br />
            of trusted expertise
          </h1>

          {/* Row C - Description */}
          <p className="text-gray-700 text-base md:text-lg max-w-2xl mb-14 leading-relaxed text-center mx-auto">
            Firesec Systems Ltd provides comprehensive fire alarm, security, and
            data infrastructure solutions. From design to installation and
            maintenance, we ensure your building stays compliant and secure.
          </p>

          {/* Row D - CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mb-16 justify-center">
            <a
              href="/contact"
              className="bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-semibold px-8 py-4 rounded-lg transition-all duration-150 ease-out active:scale-[0.98] shadow-lg text-center"
            >
              Get Free Quote
            </a>
            <a
              href="/services"
              className="border border-gray-300 hover:border-red-600 text-gray-700 hover:text-red-600 font-semibold px-8 py-4 rounded-lg transition-all duration-150 ease-out text-center"
            >
              View Our Services
            </a>
          </div>

          {/* Row E - Key Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">
                  BS5839-1 Compliant
                </h3>
                <p className="text-sm text-gray-600">Certified installations</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Phone className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">24/7 Support</h3>
                <p className="text-sm text-gray-600">Emergency response</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">
                  21+ Years Experience
                </h3>
                <p className="text-sm text-gray-600">Trusted expertise</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
