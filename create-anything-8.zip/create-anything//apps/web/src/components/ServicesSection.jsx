import {
  Flame,
  Shield,
  Key,
  Camera,
  Cable,
  Network,
  CheckCircle,
} from "lucide-react";

export default function ServicesSection() {
  const services = [
    {
      icon: Flame,
      title: "Fire Alarm Systems",
      description:
        "Design, install and maintain conventional, addressable and wireless fire alarm systems throughout Scotland. We can advise and consult on the condition of your systems and advise the correct course to ensure your building is compliant with BS5839-1.",
      features: [
        "Conventional fire alarm systems",
        "Addressable fire alarm systems",
        "Wireless fire alarm systems",
        "BS5839-1 compliance consulting",
        "System integration with plant control",
        "Fire brigade notification systems",
        "Graphic touch screen interfaces",
        "Large system isolation and control",
      ],
      color: "red",
    },
    {
      icon: Shield,
      title: "Intruder Alarm Systems",
      description:
        "We can install modular or wireless intruder alarm systems that integrate with your CCTV and access control systems throughout your building. We can install control room or mobile phone application notifications.",
      features: [
        "Modular intruder alarm systems",
        "Wireless intruder alarm systems",
        "CCTV system integration",
        "Access control integration",
        "Control room notifications",
        "Mobile phone app notifications",
        "25 years of experience",
        "Property security consulting",
      ],
      color: "blue",
    },
    {
      icon: Key,
      title: "Access Control Systems",
      description:
        "We can install basic access systems to nationwide multi-tenant access control systems, set up access control servers and integrate into any fire alarm, intruder alarm or CCTV system.",
      features: [
        "Basic access control systems",
        "Multi-tenant access control",
        "Nationwide system deployment",
        "Access control server setup",
        "Fire alarm system integration",
        "Intruder alarm integration",
        "CCTV system integration",
        "Database migration services",
        "Graphics control systems",
      ],
      color: "green",
    },
    {
      icon: Camera,
      title: "CCTV Systems",
      description:
        "We have vast experience installing and maintaining basic analogue CCTV systems to large nationwide multi-building IP CCTV systems. We have built control rooms with front-end CCTV viewing software.",
      features: [
        "Basic analogue CCTV systems",
        "Large IP CCTV systems",
        "Multi-building installations",
        "Control room construction",
        "Front-end viewing software",
        "Temperature sensing cameras",
        "Fire detection cameras",
        "Wireless ethernet bridges",
        "Fibre network transmission",
      ],
      color: "purple",
    },
    {
      icon: Cable,
      title: "Data Infrastructure",
      description:
        "We can install full office data cabling installations, run in CAT5e or CAT6 etc from cabinet to data point. We can fully test and commission all cabling as well as fault-find and inspect faulty networks.",
      features: [
        "CAT5e data cabling installation",
        "CAT6 data cabling installation",
        "Cabinet to data point runs",
        "Full testing and commissioning",
        "Network fault-finding",
        "Faulty network inspection",
        "Fibre network installation",
        "Fibre splicing and testing",
        "Future-proof installations",
      ],
      color: "orange",
    },
    {
      icon: Network,
      title: "Networking",
      description:
        "Our engineers can fault-find over corporate networks, sometimes finding the smallest of issues that normal fire & security companies overlook, due to lack of networking knowledge.",
      features: [
        "Corporate network fault-finding",
        "Complex issue resolution",
        "Security server support",
        "Nationwide server support",
        "Network issue investigation",
        "IT team collaboration",
        "Detailed networking knowledge",
        "Overlooked issue detection",
      ],
      color: "teal",
    },
  ];

  const getColorClasses = (color) => {
    const colors = {
      red: "bg-red-100 dark:bg-red-900/20 text-red-600 border-red-200 dark:border-red-800 hover:bg-red-50 dark:hover:bg-red-900/30",
      blue: "bg-blue-100 dark:bg-blue-900/20 text-blue-600 border-blue-200 dark:border-blue-800 hover:bg-blue-50 dark:hover:bg-blue-900/30",
      green:
        "bg-green-100 dark:bg-green-900/20 text-green-600 border-green-200 dark:border-green-800 hover:bg-green-50 dark:hover:bg-green-900/30",
      purple:
        "bg-purple-100 dark:bg-purple-900/20 text-purple-600 border-purple-200 dark:border-purple-800 hover:bg-purple-50 dark:hover:bg-purple-900/30",
      orange:
        "bg-orange-100 dark:bg-orange-900/20 text-orange-600 border-orange-200 dark:border-orange-800 hover:bg-orange-50 dark:hover:bg-orange-900/30",
      teal: "bg-teal-100 dark:bg-teal-900/20 text-teal-600 border-teal-200 dark:border-teal-800 hover:bg-teal-50 dark:hover:bg-teal-900/30",
    };
    return colors[color] || colors.red;
  };

  return (
    <section className="py-20 px-6 bg-gray-50 dark:bg-[#0F0F0F]">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2
            className="text-black dark:text-white font-bold leading-tight mb-4"
            style={{
              fontFamily:
                'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              fontSize: "clamp(32px, 4vw, 48px)",
            }}
          >
            Comprehensive Security Solutions
          </h2>
          <p className="text-gray-600 dark:text-gray-400 text-lg max-w-3xl mx-auto">
            From fire safety to data infrastructure, we provide end-to-end
            security solutions tailored to your specific needs across Scotland
            and beyond.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div
                key={index}
                className={`bg-white dark:bg-[#1E1E1E] border border-gray-200 dark:border-gray-700 rounded-2xl p-8 transition-all duration-300 hover:shadow-lg hover:-translate-y-1`}
              >
                {/* Icon */}
                <div
                  className={`w-16 h-16 rounded-xl flex items-center justify-center mb-6 ${getColorClasses(service.color)}`}
                >
                  <IconComponent className="w-8 h-8" />
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-black dark:text-white mb-4">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
                  {service.description}
                </p>

                {/* Features */}
                <div className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {feature}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
