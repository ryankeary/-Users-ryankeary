import { Award, Users, MapPin, Clock } from "lucide-react";

export default function AboutSection() {
  const stats = [
    {
      icon: Clock,
      number: "21+",
      label: "Years Experience",
      description: "Trusted expertise in fire & security",
    },
    {
      icon: Users,
      number: "500+",
      label: "Projects Completed",
      description: "Successful installations across Scotland",
    },
    {
      icon: MapPin,
      number: "24/7",
      label: "Support Available",
      description: "Emergency response nationwide",
    },
  ];

  return (
    <section
      className="py-24 px-6"
      style={{
        fontFamily:
          'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      }}
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left column - Content */}
          <div>
            <h2
              className="text-black dark:text-white font-bold leading-tight mb-6"
              style={{
                fontSize: "clamp(32px, 4vw, 48px)",
              }}
            >
              Your trusted security partner across Scotland
            </h2>

            <div className="space-y-6 text-gray-600 dark:text-gray-400 leading-relaxed">
              <p className="text-lg">
                Firesec Systems Ltd is a friendly, professional installation and
                servicing company with over 21 years of experience in the fire
                and security industry.
              </p>

              <p>
                We specialize in designing, installing, and maintaining
                comprehensive fire & security solutions that keep your property
                safe and compliant. From fire alarm, Intruder alarm, access
                control, CCTV Systems, to data infrastructure, our expert team
                delivers reliable solutions tailored to your specific needs.
              </p>

              <p>
                Our commitment to excellence and attention to detail has made us
                a trusted partner for businesses across Scotland. We work to the
                highest standards and can advise the correct course of action to
                secure and protect your property.
              </p>
            </div>
          </div>

          {/* Right column - Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {stats.map((stat, index) => {
              const IconComponent = stat.icon;
              return (
                <div
                  key={index}
                  className="bg-white dark:bg-[#1E1E1E] border border-gray-200 dark:border-gray-700 rounded-2xl p-6 text-center transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
                >
                  <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-8 h-8 text-red-600" />
                  </div>

                  <div className="text-3xl font-bold text-black dark:text-white mb-2">
                    {stat.number}
                  </div>

                  <div className="text-lg font-semibold text-black dark:text-white mb-2">
                    {stat.label}
                  </div>

                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    {stat.description}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Certifications & Standards */}
        <div className="mt-20 pt-16 border-t border-gray-200 dark:border-gray-700">
          <div className="text-center mb-12">
            <h3 className="text-2xl font-bold text-black dark:text-white mb-4">
              Certifications & Standards
            </h3>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              We maintain the highest industry standards and certifications to
              ensure your installations are compliant and reliable.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-10 h-10 text-red-600" />
              </div>
              <h4 className="text-lg font-semibold text-black dark:text-white mb-2">
                BS5839-1
              </h4>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Fire alarm system installations compliant with British Standards
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-10 h-10 text-red-600" />
              </div>
              <h4 className="text-lg font-semibold text-black dark:text-white mb-2">
                Industry Qualified
              </h4>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Qualified engineers for fibre networks and data infrastructure
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-10 h-10 text-red-600" />
              </div>
              <h4 className="text-lg font-semibold text-black dark:text-white mb-2">
                Professional Standards
              </h4>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Working to the highest professional standards for 21+ years
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
