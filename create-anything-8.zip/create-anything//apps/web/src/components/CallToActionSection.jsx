import { Phone, Mail, MapPin, Clock } from "lucide-react";

export default function CallToActionSection() {
  return (
    <section
      className="relative rounded-[24px] mx-6 mb-6 overflow-hidden"
      style={{
        background:
          "linear-gradient(135deg, #DC2626 0%, #B91C1C 50%, #991B1B 100%)",
        paddingTop: "10vh",
        paddingBottom: "10vh",
        paddingLeft: "clamp(4vw, 8vw, 8vw)",
        paddingRight: "clamp(4vw, 8vw, 8vw)",
        fontFamily:
          'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      }}
    >
      {/* Dark mode background overlay */}
      <div
        className="absolute inset-0 hidden dark:block"
        style={{
          background:
            "linear-gradient(135deg, #7F1D1D 0%, #991B1B 50%, #B91C1C 100%)",
        }}
      ></div>

      <div className="relative z-10">
        {/* Main headline */}
        <div className="mb-8">
          <h1
            className="text-white leading-[0.9] mb-8"
            style={{
              fontFamily:
                'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              fontSize: "clamp(2.5rem, 5vw, 4.5rem)",
              letterSpacing: "-0.04em",
              fontWeight: 800,
            }}
          >
            Ready to secure your property
            <br />
            with professional fire & security
            <br />
            solutions? Let's get started 🔥
          </h1>
        </div>

        {/* Primary CTA Button */}
        <div className="mb-16">
          <a
            href="/contact"
            className="inline-block bg-white hover:bg-gray-100 active:bg-gray-200 text-red-600 hover:text-red-700 active:text-red-800 font-semibold px-8 py-4 rounded-lg transition-all duration-150 ease-out focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-red-600 active:scale-[0.98] shadow-lg"
            style={{
              fontFamily:
                'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              height: "56px",
              paddingLeft: "32px",
              paddingRight: "32px",
              fontWeight: 600,
              fontSize: "18px",
              display: "inline-flex",
              alignItems: "center",
            }}
          >
            Get Your Free Quote Today
          </a>
        </div>

        {/* Divider */}
        <div className="w-full h-px mb-8 bg-white/20"></div>

        {/* Contact Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Phone */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <Phone className="w-5 h-5 text-white" />
              <span
                className="text-white/80 text-sm uppercase tracking-wider"
                style={{
                  fontFamily:
                    'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                  letterSpacing: "0.05em",
                  fontWeight: 500,
                }}
              >
                Call Us
              </span>
            </div>
            <a
              href="tel:+441412915054"
              className="text-white hover:text-white/80 transition-all duration-150 text-lg font-semibold"
              style={{
                fontFamily:
                  'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              }}
            >
              0141 291 5054
            </a>
            <p className="text-white/60 text-sm">24/7 Emergency Line</p>
          </div>

          {/* Email */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-white" />
              <span
                className="text-white/80 text-sm uppercase tracking-wider"
                style={{
                  fontFamily:
                    'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                  letterSpacing: "0.05em",
                  fontWeight: 500,
                }}
              >
                Email Us
              </span>
            </div>
            <a
              href="mailto:Enquiries@Firesec.Systems"
              className="text-white hover:text-white/80 transition-all duration-150 text-lg font-semibold"
              style={{
                fontFamily:
                  'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              }}
            >
              Enquiries@Firesec.Systems
            </a>
            <p className="text-white/60 text-sm">Quick Response Guaranteed</p>
          </div>

          {/* Location */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-white" />
              <span
                className="text-white/80 text-sm uppercase tracking-wider"
                style={{
                  fontFamily:
                    'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                  letterSpacing: "0.05em",
                  fontWeight: 500,
                }}
              >
                Service Area
              </span>
            </div>
            <div
              className="text-white text-lg font-semibold"
              style={{
                fontFamily:
                  'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              }}
            >
              Scotland Wide
            </div>
            <p className="text-white/60 text-sm">
              Nationwide Support Available
            </p>
          </div>

          {/* Hours */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-white" />
              <span
                className="text-white/80 text-sm uppercase tracking-wider"
                style={{
                  fontFamily:
                    'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                  letterSpacing: "0.05em",
                  fontWeight: 500,
                }}
              >
                Available
              </span>
            </div>
            <div
              className="text-white text-lg font-semibold"
              style={{
                fontFamily:
                  'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              }}
            >
              24/7 Emergency
            </div>
            <p className="text-white/60 text-sm">
              Mon-Fri 8:30 - 17:00 Regular Working Hours
            </p>
          </div>
        </div>

        {/* Bottom Note */}
        <div className="mt-12 pt-8 border-t border-white/20">
          <p className="text-white/80 text-center">
            <strong>Firesec Systems Ltd</strong> - Your trusted partner for fire
            and security solutions across Scotland. Over 21 years of
            professional service and support.
          </p>
        </div>
      </div>
    </section>
  );
}
