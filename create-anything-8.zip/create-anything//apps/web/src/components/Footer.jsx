export default function Footer() {
  return (
    <footer className="bg-gray-50 dark:bg-[#1E1E1E] border-t border-gray-200 dark:border-gray-700 py-8 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center">
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8 text-sm text-gray-600 dark:text-gray-400">
            <div className="flex items-center gap-2">
              <span className="font-semibold">
                Company Registration Number:
              </span>
              <span>SC857954</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-semibold">24/7 Contact:</span>
              <a
                href="tel:+441412915054"
                className="text-red-600 hover:text-red-700 transition-colors"
              >
                0141 291 5054
              </a>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-semibold">Email:</span>
              <a
                href="mailto:Enquiries@Firesec.Systems"
                className="text-red-600 hover:text-red-700 transition-colors"
              >
                Enquiries@Firesec.Systems
              </a>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
            <p className="text-xs text-gray-500 dark:text-gray-500">
              © {new Date().getFullYear()} Firesec Systems Ltd. All rights
              reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
