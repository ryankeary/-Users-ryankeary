import Header from "../../components/Header";
import Footer from "../../components/Footer";
import {
  Flame,
  Shield,
  Key,
  Camera,
  Cable,
  Network,
  ArrowRight,
  CheckCircle,
} from "lucide-react";

export default function ServicesPage() {
  const services = [
    {
      icon: Flame,
      title: "Fire Alarm Systems",
      description:
        "Design, install and maintain conventional, addressable and wireless fire alarm systems throughout Scotland. We can advise and consult on the condition of your systems and advise the correct course to ensure your building is compliant with BS5839-1.",
      features: [
        "Conventional fire alarm systems",
        "Addressable fire alarm systems",
        "Wireless fire alarm systems",
        "BS5839-1 compliance consulting",
        "System integration with plant control",
        "Fire brigade notification systems",
        "Graphic touch screen interfaces",
        "Large system isolation and control",
      ],
      href: "/services/fire-alarms",
    },
    {
      icon: Shield,
      title: "Intruder Alarm Systems",
      description:
        "We can install modular or wireless intruder alarm systems that integrate with your CCTV and access control systems throughout your building. We can install control room or mobile phone application notifications.",
      features: [
        "Modular intruder alarm systems",
        "Wireless intruder alarm systems",
        "CCTV system integration",
        "Access control integration",
        "Control room notifications",
        "Mobile phone app notifications",
        "25 years of experience",
        "Property security consulting",
      ],
      href: "/services/intruder-alarms",
    },
    {
      icon: Key,
      title: "Access Control Systems",
      description:
        "We can install basic access systems to nationwide multi-tenant access control systems, set up access control servers and integrate into any fire alarm, intruder alarm or CCTV system.",
      features: [
        "Basic access control systems",
        "Multi-tenant access control",
        "Nationwide system deployment",
        "Access control server setup",
        "Fire alarm system integration",
        "Intruder alarm integration",
        "CCTV system integration",
        "Database migration services",
        "Graphics control systems",
      ],
      href: "/services/access-control",
    },
    {
      icon: Camera,
      title: "CCTV Systems",
      description:
        "We have vast experience installing and maintaining basic analogue CCTV systems to large nationwide multi-building IP CCTV systems. We have built control rooms with front-end CCTV viewing software.",
      features: [
        "Basic analogue CCTV systems",
        "Large IP CCTV systems",
        "Multi-building installations",
        "Control room construction",
        "Front-end viewing software",
        "Temperature sensing cameras",
        "Fire detection cameras",
        "Wireless ethernet bridges",
        "Fibre network transmission",
      ],
      href: "/services/cctv",
    },
    {
      icon: Cable,
      title: "Data Infrastructure",
      description:
        "We can install full office data cabling installations, run in CAT5e or CAT6 etc from cabinet to data point. We can fully test and commission all cabling as well as fault-find and inspect faulty networks.",
      features: [
        "CAT5e data cabling installation",
        "CAT6 data cabling installation",
        "Cabinet to data point runs",
        "Full testing and commissioning",
        "Network fault-finding",
        "Faulty network inspection",
        "Fibre network installation",
        "Fibre splicing and testing",
        "Future-proof installations",
      ],
      href: "/services/data-infrastructure",
    },
    {
      icon: Network,
      title: "Networking",
      description:
        "Our engineers can fault-find over corporate networks, sometimes finding the smallest of issues that normal fire & security companies overlook, due to lack of networking knowledge.",
      features: [
        "Corporate network fault-finding",
        "Complex issue resolution",
        "Security server support",
        "Nationwide server support",
        "Network issue investigation",
        "IT team collaboration",
        "Detailed networking knowledge",
        "Overlooked issue detection",
      ],
      href: "/services/networking",
    },
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-[#121212]">
      <Header />

      {/* Hero Section */}
      <section className="pt-8 pb-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="bg-white dark:bg-[#1E1E1E] border border-[#F1F1F4] dark:border-[#333333] rounded-[40px] p-16 md:p-8 text-center">
            <h1
              className="text-black dark:text-white font-bold leading-tight mb-6"
              style={{
                fontSize: "clamp(36px, 5vw, 56px)",
                fontFamily:
                  'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              }}
            >
              Our Services
            </h1>
            <p className="text-gray-600 dark:text-gray-400 text-lg max-w-3xl mx-auto">
              Comprehensive fire and security solutions designed to protect your
              property and ensure compliance. With over 21 years of experience,
              we deliver professional installations and maintenance across
              Scotland.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="pb-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {services.map((service, index) => {
              const IconComponent = service.icon;
              return (
                <div
                  key={index}
                  className="bg-white dark:bg-[#1E1E1E] border border-gray-200 dark:border-gray-700 rounded-2xl p-8 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 group"
                >
                  {/* Header */}
                  <div className="flex items-start gap-4 mb-6">
                    <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-xl flex items-center justify-center flex-shrink-0">
                      <IconComponent className="w-8 h-8 text-red-600" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-black dark:text-white mb-2">
                        {service.title}
                      </h3>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
                    {service.description}
                  </p>

                  {/* Features */}
                  <div className="mb-8">
                    <h4 className="text-lg font-semibold text-black dark:text-white mb-4">
                      What we offer:
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {service.features.map((feature, featureIndex) => (
                        <div
                          key={featureIndex}
                          className="flex items-center gap-2"
                        >
                          <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            {feature}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="pb-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gray-50 dark:bg-[#1E1E1E] border border-gray-200 dark:border-gray-700 rounded-2xl p-12">
            <h2 className="text-3xl font-bold text-black dark:text-white mb-4">
              Need a Custom Solution?
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-8 text-lg">
              Every property is unique. We can design and implement bespoke fire
              and security solutions tailored to your specific requirements and
              budget.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-red-600 hover:bg-red-700 text-white font-semibold px-8 py-4 rounded-lg transition-all duration-150">
                Get Free Consultation
              </button>
              <button className="border border-gray-300 dark:border-gray-600 hover:border-red-600 text-gray-700 dark:text-gray-300 hover:text-red-600 font-semibold px-8 py-4 rounded-lg transition-all duration-150">
                Call Us Now
              </button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
