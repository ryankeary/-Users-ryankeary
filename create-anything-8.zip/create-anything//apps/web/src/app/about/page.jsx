"use client";

import Header from "../../components/Header";
import Footer from "../../components/Footer";
import {
  Award,
  Users,
  MapPin,
  Clock,
  Shield,
  Target,
  Heart,
  Upload,
  FileText,
  X,
  Trash2,
  Save,
  Monitor, // Add Monitor icon for computer
} from "lucide-react";
import { useState, useCallback } from "react";
import useUpload from "../../utils/useUpload";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export default function AboutPage() {
  const [uploadedDocument, setUploadedDocument] = useState(null);
  const [error, setError] = useState(null);
  const [upload, { loading }] = useUpload();
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("general");
  const queryClient = useQueryClient();

  // Fetch saved documents
  const { data: savedDocuments = [], isLoading: documentsLoading } = useQuery({
    queryKey: ["company-documents"],
    queryFn: async () => {
      const response = await fetch("/api/documents");
      if (!response.ok) {
        throw new Error("Failed to fetch documents");
      }
      const data = await response.json();
      return data.documents || [];
    },
  });

  // Save document mutation
  const saveDocumentMutation = useMutation({
    mutationFn: async (documentData) => {
      const response = await fetch("/api/documents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(documentData),
      });
      if (!response.ok) {
        throw new Error("Failed to save document");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["company-documents"] });
      // Reset form
      setUploadedDocument(null);
      setDescription("");
      setCategory("general");
      setError(null);
    },
    onError: (err) => {
      setError("Failed to save document");
      console.error(err);
    },
  });

  // Delete document mutation
  const deleteDocumentMutation = useMutation({
    mutationFn: async (documentId) => {
      const response = await fetch(`/api/documents/${documentId}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        throw new Error("Failed to delete document");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["company-documents"] });
    },
    onError: (err) => {
      setError("Failed to delete document");
      console.error(err);
    },
  });

  const handleFileUpload = useCallback(
    async (event) => {
      const file = event.target.files[0];
      if (!file) return;

      setError(null);

      // Create a file URL for preview
      const fileUrl = URL.createObjectURL(file);

      try {
        const { url, mimeType, error } = await upload({ file });
        if (error) {
          setError(error);
          return;
        }

        setUploadedDocument({
          url,
          name: file.name,
          type: mimeType,
          size: file.size,
          localUrl: fileUrl,
        });
      } catch (err) {
        setError("Failed to upload document");
        console.error(err);
      }
    },
    [upload],
  );

  const handleSaveDocument = useCallback(() => {
    if (!uploadedDocument) return;

    saveDocumentMutation.mutate({
      name: uploadedDocument.name,
      file_url: uploadedDocument.url,
      mime_type: uploadedDocument.type,
      file_size: uploadedDocument.size,
      description: description.trim(),
      category: category,
    });
  }, [uploadedDocument, description, category, saveDocumentMutation]);

  const handleDeleteDocument = useCallback(
    (documentId, documentName) => {
      if (
        window.confirm(`Are you sure you want to delete "${documentName}"?`)
      ) {
        deleteDocumentMutation.mutate(documentId);
      }
    },
    [deleteDocumentMutation],
  );

  const removeDocument = useCallback(() => {
    if (uploadedDocument?.localUrl) {
      URL.revokeObjectURL(uploadedDocument.localUrl);
    }
    setUploadedDocument(null);
    setDescription("");
    setCategory("general");
    setError(null);
  }, [uploadedDocument]);

  const stats = [
    {
      icon: Clock,
      number: "21+",
      label: "Years Experience",
      description: "Trusted expertise in fire & security",
    },
    {
      icon: Users,
      number: "500+",
      label: "Projects Completed",
      description: "Successful installations across Scotland",
    },
    {
      icon: MapPin,
      number: "24/7",
      label: "Support Available",
      description: "Emergency response nationwide",
    },
    {
      icon: Monitor,
      number: "24/7",
      label: "Remote Support",
      description:
        "Remote support for software and servers throughout all of our clients estates",
      downloads: [
        {
          label: "Windows",
          file: "https://temp365mail-my.sharepoint.com/:u:/g/personal/ryan_keary_firesec_systems/ESJc-WJLxGRGhoNTLxrRUykB1LwicrpeUC9eX54EPZap-A?e=dyeQvf",
        },
        {
          label: "Mac",
          file: "https://temp365mail-my.sharepoint.com/:u:/g/personal/ryan_keary_firesec_systems/EdvLHhXijUtHpqhx2lhQGAUBtj4x9dghLpU9pMMPLYkyKg?e=1DtXaj",
        },
      ],
    },
  ];

  const values = [
    {
      icon: Shield,
      title: "Safety First",
      description:
        "Your safety is our top priority. We ensure every installation meets the highest safety standards and compliance requirements.",
    },
    {
      icon: Target,
      title: "Precision & Quality",
      description:
        "We deliver precise, high-quality installations with attention to detail that ensures long-lasting, reliable security solutions.",
    },
    {
      icon: Heart,
      title: "Customer Care",
      description:
        "We build lasting relationships with our clients through exceptional service, ongoing support, and genuine care for their security needs.",
    },
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-[#121212]">
      <Header />

      {/* Hero Section */}
      <section className="pt-8 pb-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="bg-white dark:bg-[#1E1E1E] border border-[#F1F1F4] dark:border-[#333333] rounded-[40px] p-16 md:p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h1
                  className="text-black dark:text-white font-bold leading-tight mb-6"
                  style={{
                    fontSize: "clamp(36px, 5vw, 56px)",
                    fontFamily:
                      'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                  }}
                >
                  About Firesec Systems Ltd
                </h1>
                <p className="text-gray-600 dark:text-gray-400 text-lg leading-relaxed mb-6">
                  We are a friendly, professional installation and servicing
                  company with over 21 years of experience in the fire and
                  security industry.
                </p>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                  Our commitment to excellence and attention to detail has made
                  us a trusted partner for businesses across Scotland. We work
                  to the highest standards and can advise the correct course of
                  action to secure and protect your property.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {stats.map((stat, index) => {
                  const IconComponent = stat.icon;
                  return (
                    <div
                      key={index}
                      className="bg-gray-50 dark:bg-[#2A2A2A] border border-gray-200 dark:border-gray-600 rounded-xl p-6 text-center"
                    >
                      <div className="w-12 h-12 bg-red-100 dark:bg-red-900/20 rounded-lg flex items-center justify-center mx-auto mb-3">
                        <IconComponent className="w-6 h-6 text-red-600" />
                      </div>
                      <div className="text-2xl font-bold text-black dark:text-white mb-1">
                        {stat.number}
                      </div>
                      <div className="text-sm font-semibold text-black dark:text-white mb-1">
                        {stat.label}
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400 mb-3">
                        {stat.description}
                      </div>
                      {stat.downloads && (
                        <div className="space-y-2">
                          {stat.downloads.map((download, downloadIndex) => (
                            <a
                              key={downloadIndex}
                              href={
                                download.file.startsWith("http")
                                  ? download.file
                                  : `/${download.file}`
                              }
                              target={
                                download.file.startsWith("http")
                                  ? "_blank"
                                  : "_self"
                              }
                              rel={
                                download.file.startsWith("http")
                                  ? "noopener noreferrer"
                                  : undefined
                              }
                              className="block bg-red-600 hover:bg-red-700 text-white text-xs font-semibold px-3 py-2 rounded-lg transition-all duration-150"
                            >
                              {download.label}
                            </a>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 px-6 bg-gray-50 dark:bg-[#0F0F0F]">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-black dark:text-white mb-8">
            Our Story
          </h2>
          <div className="space-y-6 text-gray-600 dark:text-gray-400 leading-relaxed">
            <p className="text-lg">
              Although only recently founded, Firesec Systems Ltd management and
              engineering team have decades of experience over the years. It
              began with a simple mission: to provide reliable, professional
              fire and security solutions that truly protect what matters most.
            </p>
            <p>
              Although we are a small team of dedicated engineers we plan to
              grow into Scotland's trusted partner for comprehensive fire &
              security solutions. We've built our reputation on technical
              expertise, unwavering commitment to quality, and genuine care for
              our clients' safety and peace of mind.
            </p>
            <p>
              Today, we continue to evolve with the latest technologies while
              maintaining the personal touch and attention to detail that has
              defined us from the beginning. Every project, whether large or
              small, receives the same level of professional care and expertise.
            </p>
            <p>
              Our team have worked in every sector, including banking, retail,
              fire brigade, police as well as the courts system. We believe in
              the saying.... "Your only as good, as your last job" which reminds
              us to strive for excellence in all of our installations. With
              basically no advertising carried out, we maintain a steady work
              flow.
            </p>
            <p>
              Our Managing Director was previously the Technical Director at his
              previous company, where he took on the more complex issues, like
              nationwide contract monitoring migrations, access control and cctv
              server installation and maintenance, and remote service support.
            </p>
            <p>
              Our reputation in our industry is why our clients can rest assured
              they are in good hands!
            </p>
          </div>
        </div>
      </section>

      {/* Document Management Section */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-black dark:text-white mb-4">
              Company Documents
            </h2>
            <p className="text-gray-600 dark:text-gray-400 text-lg max-w-3xl mx-auto">
              Upload and manage important company documents, certifications, and
              compliance materials that clients can securely access.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Upload & Save Section */}
            <div className="bg-white dark:bg-[#1E1E1E] border border-gray-200 dark:border-gray-700 rounded-2xl p-8">
              <h3 className="text-xl font-bold text-black dark:text-white mb-6">
                Upload New Document
              </h3>

              {!uploadedDocument ? (
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center">
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h4 className="text-lg font-semibold text-black dark:text-white mb-2">
                    Choose a document to upload
                  </h4>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    PDF, DOC, DOCX files supported
                  </p>
                  <label className="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-3 rounded-lg cursor-pointer transition-all duration-150 inline-block">
                    {loading ? "Uploading..." : "Choose File"}
                    <input
                      type="file"
                      className="hidden"
                      accept=".pdf,.doc,.docx"
                      onChange={handleFileUpload}
                      disabled={loading}
                    />
                  </label>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Document Info */}
                  <div className="border border-gray-200 dark:border-gray-600 rounded-lg p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <FileText className="w-8 h-8 text-red-600" />
                        <div>
                          <h4 className="font-semibold text-black dark:text-white">
                            {uploadedDocument.name}
                          </h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {uploadedDocument.type}
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={removeDocument}
                        className="text-gray-400 hover:text-red-600 transition-colors"
                        title="Remove document"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                    <div className="flex gap-3">
                      <a
                        href={uploadedDocument.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-gray-100 dark:bg-gray-700 text-black dark:text-white font-semibold px-4 py-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-150 text-sm"
                      >
                        Preview Document
                      </a>
                    </div>
                  </div>

                  {/* Document Details Form */}
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-black dark:text-white mb-2">
                        Category
                      </label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-black dark:text-white focus:ring-2 focus:ring-red-600 focus:border-transparent transition-all"
                      >
                        <option value="general">General</option>
                        <option value="certifications">Certifications</option>
                        <option value="compliance">Compliance</option>
                        <option value="insurance">Insurance</option>
                        <option value="safety">Safety Documents</option>
                        <option value="technical">
                          Technical Specifications
                        </option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-black dark:text-white mb-2">
                        Description (Optional)
                      </label>
                      <textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="Enter a description for this document..."
                        rows={3}
                        className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-black dark:text-white focus:ring-2 focus:ring-red-600 focus:border-transparent transition-all resize-none"
                      />
                    </div>

                    <button
                      onClick={handleSaveDocument}
                      disabled={saveDocumentMutation.isPending}
                      className="w-full bg-red-600 hover:bg-red-700 disabled:bg-red-400 text-white font-semibold px-6 py-3 rounded-lg transition-all duration-150 flex items-center justify-center gap-2"
                    >
                      <Save className="w-5 h-5" />
                      {saveDocumentMutation.isPending
                        ? "Saving..."
                        : "Save Document"}
                    </button>
                  </div>
                </div>
              )}

              {error && (
                <div className="mt-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                  <p className="text-red-600 dark:text-red-400 text-sm">
                    {error}
                  </p>
                </div>
              )}
            </div>

            {/* Saved Documents Section */}
            <div className="bg-white dark:bg-[#1E1E1E] border border-gray-200 dark:border-gray-700 rounded-2xl p-8">
              <h3 className="text-xl font-bold text-black dark:text-white mb-6">
                Saved Documents
              </h3>

              {documentsLoading ? (
                <div className="text-center py-8">
                  <p className="text-gray-600 dark:text-gray-400">
                    Loading documents...
                  </p>
                </div>
              ) : savedDocuments.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 dark:text-gray-400">
                    No saved documents yet
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">
                    Upload and save documents to make them available to clients
                  </p>
                </div>
              ) : (
                <div className="space-y-4 max-h-[500px] overflow-y-auto">
                  {savedDocuments.map((doc) => (
                    <div
                      key={doc.id}
                      className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3 flex-1">
                          <FileText className="w-6 h-6 text-red-600 mt-1 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <h4 className="font-semibold text-black dark:text-white truncate">
                              {doc.name}
                            </h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">
                              {doc.category}
                            </p>
                            {doc.description && (
                              <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                                {doc.description}
                              </p>
                            )}
                            <p className="text-xs text-gray-400 mt-2">
                              Uploaded{" "}
                              {new Date(doc.uploaded_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <a
                            href={doc.file_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-red-600 hover:bg-red-700 text-white font-semibold px-3 py-2 rounded-lg transition-all duration-150 text-sm"
                          >
                            View
                          </a>
                          <button
                            onClick={() =>
                              handleDeleteDocument(doc.id, doc.name)
                            }
                            disabled={deleteDocumentMutation.isPending}
                            className="text-gray-400 hover:text-red-600 transition-colors p-2"
                            title="Delete document"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-black dark:text-white mb-4">
              Our Values
            </h2>
            <p className="text-gray-600 dark:text-gray-400 text-lg max-w-3xl mx-auto">
              These core values guide everything we do and shape how we serve
              our clients across Scotland.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => {
              const IconComponent = value.icon;
              return (
                <div
                  key={index}
                  className="bg-white dark:bg-[#1E1E1E] border border-gray-200 dark:border-gray-700 rounded-2xl p-8 text-center transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
                >
                  <div className="w-20 h-20 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <IconComponent className="w-10 h-10 text-red-600" />
                  </div>
                  <h3 className="text-xl font-bold text-black dark:text-white mb-4">
                    {value.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                    {value.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-red-600 rounded-2xl p-12 text-white">
            <h2 className="text-3xl font-bold mb-4">
              Ready to Work with Scotland's Trusted Security Experts?
            </h2>
            <p className="text-red-100 mb-8 text-lg">
              With over 21 years of experience and hundreds of successful
              projects, we're ready to secure your property with professional,
              compliant solutions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/contact"
                className="bg-white text-red-600 font-semibold px-8 py-4 rounded-lg hover:bg-gray-100 transition-all duration-150 text-center"
              >
                Get Your Free Quote
              </a>
              <a
                href="tel:+441412915054"
                className="border-2 border-white text-white font-semibold px-8 py-4 rounded-lg hover:bg-white hover:text-red-600 transition-all duration-150 text-center"
              >
                Call Us Today
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
