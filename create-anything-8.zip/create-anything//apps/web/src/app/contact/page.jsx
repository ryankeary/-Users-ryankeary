"use client";

import { useState } from "react";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Send,
  Upload,
  FileText,
  X,
  Image,
} from "lucide-react";
import useUpload from "../../utils/useUpload";

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState(null);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [uploadError, setUploadError] = useState(null);
  const [upload, { loading: uploadLoading }] = useUpload();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleFileUpload = async (event) => {
    const files = Array.from(event.target.files);
    if (files.length === 0) return;

    setUploadError(null);

    for (const file of files) {
      try {
        const { url, mimeType, error } = await upload({ file });
        if (error) {
          setUploadError(error);
          continue;
        }

        const newFile = {
          id: Date.now() + Math.random(),
          url,
          name: file.name,
          type: mimeType,
          size: file.size,
        };

        setUploadedFiles((prev) => [...prev, newFile]);
      } catch (err) {
        setUploadError("Failed to upload file");
        console.error(err);
      }
    }

    // Reset the input
    event.target.value = "";
  };

  const removeFile = (fileId) => {
    setUploadedFiles((prev) => prev.filter((file) => file.id !== fileId));
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const getFileIcon = (mimeType) => {
    if (mimeType?.startsWith("image/")) {
      return Image;
    }
    return FileText;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus(null);

    try {
      // Simulate form submission
      await new Promise((resolve) => setTimeout(resolve, 1000));
      setSubmitStatus("success");
      setFormData({
        name: "",
        email: "",
        phone: "",
        service: "",
        message: "",
      });
      setUploadedFiles([]);
    } catch (error) {
      setSubmitStatus("error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const contactInfo = [
    {
      icon: Phone,
      title: "Phone",
      details: "0141 291 5054",
      subtitle: "24/7 Emergency Line",
      href: "tel:+441412915054",
    },
    {
      icon: Mail,
      title: "Email",
      details: "Enquiries@Firesec.Systems",
      subtitle: "Quick Response Guaranteed",
      href: "mailto:Enquiries@Firesec.Systems",
    },
    {
      icon: MapPin,
      title: "Service Area",
      details: "Scotland Wide",
      subtitle: "Nationwide Support Available",
      href: null,
    },
    {
      icon: Clock,
      title: "Hours",
      details: "24/7 Emergency",
      subtitle: "Mon-Fri 8AM-6PM Regular",
      href: null,
    },
  ];

  const services = [
    "Fire Alarm Systems",
    "Intruder Alarm Systems",
    "Access Control Systems",
    "CCTV Systems",
    "Data Infrastructure",
    "Networking",
    "Emergency Repair",
    "System Maintenance",
    "Other",
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-[#121212]">
      <Header />

      {/* Hero Section */}
      <section className="pt-8 pb-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="bg-white dark:bg-[#1E1E1E] border border-[#F1F1F4] dark:border-[#333333] rounded-[40px] p-16 md:p-8 text-center">
            <h1
              className="text-black dark:text-white font-bold leading-tight mb-6"
              style={{
                fontSize: "clamp(36px, 5vw, 56px)",
                fontFamily:
                  'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
              }}
            >
              Get In Touch
            </h1>
            <p className="text-gray-600 dark:text-gray-400 text-lg max-w-3xl mx-auto">
              Ready to secure your property? Contact Firesec Systems Ltd today
              for a free consultation and quote. Our expert team is here to help
              with all your fire and security needs.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="pb-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {contactInfo.map((info, index) => {
              const IconComponent = info.icon;
              const content = (
                <div className="bg-white dark:bg-[#1E1E1E] border border-gray-200 dark:border-gray-700 rounded-2xl p-6 text-center transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                  <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-8 h-8 text-red-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-black dark:text-white mb-2">
                    {info.title}
                  </h3>
                  <p className="text-xl font-bold text-red-600 mb-1">
                    {info.details}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {info.subtitle}
                  </p>
                </div>
              );

              return info.href ? (
                <a key={index} href={info.href} className="block">
                  {content}
                </a>
              ) : (
                <div key={index}>{content}</div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="pb-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white dark:bg-[#1E1E1E] border border-gray-200 dark:border-gray-700 rounded-2xl p-8">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-black dark:text-white mb-4">
                Request a Free Quote
              </h2>
              <p className="text-gray-600 dark:text-gray-400">
                Fill out the form below and we'll get back to you within 24
                hours with a detailed quote.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label
                    htmlFor="name"
                    className="block text-sm font-semibold text-black dark:text-white mb-2"
                  >
                    Full Name *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-red-600 focus:border-transparent bg-white dark:bg-[#2A2A2A] text-black dark:text-white"
                    placeholder="Enter your full name"
                  />
                </div>

                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-semibold text-black dark:text-white mb-2"
                  >
                    Email Address *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-red-600 focus:border-transparent bg-white dark:bg-[#2A2A2A] text-black dark:text-white"
                    placeholder="Enter your email address"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label
                    htmlFor="phone"
                    className="block text-sm font-semibold text-black dark:text-white mb-2"
                  >
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-red-600 focus:border-transparent bg-white dark:bg-[#2A2A2A] text-black dark:text-white"
                    placeholder="Enter your phone number"
                  />
                </div>

                <div>
                  <label
                    htmlFor="service"
                    className="block text-sm font-semibold text-black dark:text-white mb-2"
                  >
                    Service Required *
                  </label>
                  <select
                    id="service"
                    name="service"
                    value={formData.service}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-red-600 focus:border-transparent bg-white dark:bg-[#2A2A2A] text-black dark:text-white"
                  >
                    <option value="">Select a service</option>
                    {services.map((service, index) => (
                      <option key={index} value={service}>
                        {service}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="message"
                  className="block text-sm font-semibold text-black dark:text-white mb-2"
                >
                  Message *
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  required
                  rows={6}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-red-600 focus:border-transparent bg-white dark:bg-[#2A2A2A] text-black dark:text-white resize-vertical"
                  placeholder="Please describe your requirements, property type, and any specific needs..."
                />
              </div>

              {/* File Upload Section */}
              <div>
                <label className="block text-sm font-semibold text-black dark:text-white mb-2">
                  Attachments
                </label>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                  Upload photos, floor plans, existing system documentation, or
                  any other relevant files
                </p>

                <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center hover:border-red-400 transition-colors">
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h4 className="text-lg font-semibold text-black dark:text-white mb-2">
                    Drop files here or click to upload
                  </h4>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Supports images, PDFs, documents, and more (max 10MB per
                    file)
                  </p>
                  <label className="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-3 rounded-lg cursor-pointer transition-all duration-150 inline-block">
                    {uploadLoading ? "Uploading..." : "Choose Files"}
                    <input
                      type="file"
                      className="hidden"
                      multiple
                      accept="image/*,.pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.gif"
                      onChange={handleFileUpload}
                      disabled={uploadLoading}
                    />
                  </label>
                </div>

                {/* Display uploaded files */}
                {uploadedFiles.length > 0 && (
                  <div className="mt-4 space-y-3">
                    <h5 className="text-sm font-semibold text-black dark:text-white">
                      Uploaded Files ({uploadedFiles.length})
                    </h5>
                    <div className="space-y-2">
                      {uploadedFiles.map((file) => {
                        const FileIcon = getFileIcon(file.type);
                        return (
                          <div
                            key={file.id}
                            className="flex items-center justify-between p-3 bg-gray-50 dark:bg-[#2A2A2A] border border-gray-200 dark:border-gray-600 rounded-lg"
                          >
                            <div className="flex items-center gap-3">
                              <FileIcon className="w-6 h-6 text-red-600" />
                              <div>
                                <p className="font-medium text-black dark:text-white text-sm">
                                  {file.name}
                                </p>
                                <p className="text-xs text-gray-600 dark:text-gray-400">
                                  {formatFileSize(file.size)}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <a
                                href={file.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-red-600 hover:text-red-700 text-sm font-medium"
                              >
                                View
                              </a>
                              <button
                                type="button"
                                onClick={() => removeFile(file.id)}
                                className="text-gray-400 hover:text-red-600 transition-colors"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Upload error display */}
                {uploadError && (
                  <div className="mt-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                    <p className="text-red-600 dark:text-red-400 text-sm">
                      {uploadError}
                    </p>
                  </div>
                )}
              </div>

              {submitStatus === "success" && (
                <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                  <p className="text-green-800 dark:text-green-400 font-semibold">
                    Thank you! Your message has been sent successfully. We'll
                    get back to you within 24 hours.
                  </p>
                </div>
              )}

              {submitStatus === "error" && (
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                  <p className="text-red-800 dark:text-red-400 font-semibold">
                    Sorry, there was an error sending your message. Please try
                    again or call us directly.
                  </p>
                </div>
              )}

              <div className="text-center">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center gap-2 bg-red-600 hover:bg-red-700 disabled:bg-red-400 text-white font-semibold px-8 py-4 rounded-lg transition-all duration-150 active:scale-[0.98] shadow-lg"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Sending...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      <span>Send Message</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* Emergency Contact */}
      <section className="pb-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="bg-red-600 rounded-2xl p-8 text-center text-white">
            <h2 className="text-2xl font-bold mb-4">
              Emergency? Need Immediate Assistance?
            </h2>
            <p className="text-red-100 mb-6">
              For urgent fire and security emergencies, call our 24/7 emergency
              line now.
            </p>
            <a
              href="tel:+441412915054"
              className="inline-flex items-center gap-2 bg-white text-red-600 font-bold px-8 py-4 rounded-lg hover:bg-gray-100 transition-all duration-150 text-lg"
            >
              <Phone className="w-6 h-6" />
              <span>0141 291 5054</span>
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
