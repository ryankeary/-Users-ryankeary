import sql from "../../utils/sql";

// Delete a document
export async function DELETE(request, { params }) {
  try {
    const { id } = params;

    if (!id) {
      return Response.json(
        { error: "Document ID is required" },
        { status: 400 },
      );
    }

    const result = await sql`
      DELETE FROM company_documents 
      WHERE id = ${id}
      RETURNING id, name
    `;

    if (result.length === 0) {
      return Response.json({ error: "Document not found" }, { status: 404 });
    }

    return Response.json({
      message: "Document deleted successfully",
      deleted: result[0],
    });
  } catch (error) {
    console.error("Error deleting document:", error);
    return Response.json(
      { error: "Failed to delete document" },
      { status: 500 },
    );
  }
}

// Get a single document
export async function GET(request, { params }) {
  try {
    const { id } = params;

    if (!id) {
      return Response.json(
        { error: "Document ID is required" },
        { status: 400 },
      );
    }

    const result = await sql`
      SELECT id, name, file_url, mime_type, file_size, description, category, uploaded_at
      FROM company_documents 
      WHERE id = ${id} AND is_public = true
    `;

    if (result.length === 0) {
      return Response.json({ error: "Document not found" }, { status: 404 });
    }

    return Response.json({ document: result[0] });
  } catch (error) {
    console.error("Error fetching document:", error);
    return Response.json(
      { error: "Failed to fetch document" },
      { status: 500 },
    );
  }
}