import sql from "../utils/sql";

// Get all company documents
export async function GET() {
  try {
    const documents = await sql`
      SELECT id, name, file_url, mime_type, file_size, description, category, uploaded_at
      FROM company_documents 
      WHERE is_public = true
      ORDER BY uploaded_at DESC
    `;

    return Response.json({ documents });
  } catch (error) {
    console.error("Error fetching documents:", error);
    return Response.json(
      { error: "Failed to fetch documents" },
      { status: 500 },
    );
  }
}

// Save a new document
export async function POST(request) {
  try {
    const body = await request.json();
    const { name, file_url, mime_type, file_size, description, category } =
      body;

    if (!name || !file_url || !mime_type) {
      return Response.json(
        { error: "Name, file_url, and mime_type are required" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO company_documents (name, file_url, mime_type, file_size, description, category)
      VALUES (${name}, ${file_url}, ${mime_type}, ${file_size || null}, ${description || null}, ${category || "general"})
      RETURNING id, name, file_url, mime_type, file_size, description, category, uploaded_at
    `;

    return Response.json({ document: result[0] });
  } catch (error) {
    console.error("Error saving document:", error);
    return Response.json({ error: "Failed to save document" }, { status: 500 });
  }
}